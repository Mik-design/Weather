package kg.tutorial.weathermvvm.models

object Constants {
    const val iconUri = "https://openweathermap.org/img/wn/"
    const val iconFormat = "@2x.png"
}