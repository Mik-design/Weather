package kg.tutorial.weathermvvm.models


data class Post(
    var id: String? = null,
    var userId: String? = null,
    var title: String? = null,
    var body: String? = null
)
